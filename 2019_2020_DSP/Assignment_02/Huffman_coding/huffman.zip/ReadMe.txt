%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
%           huffman code   Read Me                        %
%                                                         %
%                                                         %
% Last update: 04 july 2004                               %
% by Pepecito, pepecito@email.it                          %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

###################################
#                                 #
#     Content of ZIP archive      #
#                                 #
###################################

 1. norm2huff.m         (encoder function)
 2. huff2norm.m         (decoder function)
 3. frequency.m         (private function)
 4. huffcodes2bin.m     (binary rapresentation of huffman codes)
 5. huffman_bench1.m    (benchmark)
 6. huffman_demo1.m     (demo file)
 7. huffman_demo2.m     (demo file)
 8. huffman_test1.m     (test file)
 9. huffman_test2.m     (test file)
10. huffman_docs.zip    (documentation)
11. Disclamer.txt       (this is the disclamer)
12. ReadMe.txt          (this file)


###################################
#                                 #
#             NOTES               #
#                                 #
###################################

The function has been created using the following Matlab version:

>> version

ans =

6.1.0.450 (R12.1)